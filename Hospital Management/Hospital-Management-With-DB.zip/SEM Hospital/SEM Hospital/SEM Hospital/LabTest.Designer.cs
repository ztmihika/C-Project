﻿
namespace SEM_Hospital
{
    partial class LabTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LabTest));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LTestIdTb = new System.Windows.Forms.TextBox();
            this.LabTestDGV = new System.Windows.Forms.DataGridView();
            this.LCostTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LUpdateBtn = new System.Windows.Forms.Button();
            this.LSearchBtn = new System.Windows.Forms.Button();
            this.LAddBtn = new System.Windows.Forms.Button();
            this.LDeleteBtn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.LClearTb = new System.Windows.Forms.Button();
            this.LNameTb = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LabTestDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Tomato;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox12);
            this.panel2.Location = new System.Drawing.Point(215, -8);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(714, 85);
            this.panel2.TabIndex = 191;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(3, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(413, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "SEM HOSPITAL LAB-TEST";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::SEM_Hospital.Properties.Resources.cancel_icon_transparent_21;
            this.pictureBox12.Location = new System.Drawing.Point(633, 7);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(81, 59);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 16;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.DarkRed;
            this.label7.Location = new System.Drawing.Point(232, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 32);
            this.label7.TabIndex = 193;
            this.label7.Text = "Test Id";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MintCream;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-4, -11);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(219, 632);
            this.panel1.TabIndex = 192;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.MintCream;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(68, 326);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 28);
            this.label5.TabIndex = 17;
            this.label5.Text = "Labrotary";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(50, 413);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 28);
            this.label4.TabIndex = 17;
            this.label4.Text = "Receptionist";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(65, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 28);
            this.label3.TabIndex = 17;
            this.label3.Text = "Doctor";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(65, 146);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 28);
            this.label6.TabIndex = 17;
            this.label6.Text = "Patient";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::SEM_Hospital.Properties.Resources.Lab;
            this.pictureBox6.Location = new System.Drawing.Point(3, 326);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(44, 44);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 16;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SEM_Hospital.Properties.Resources.Receptionist;
            this.pictureBox5.Location = new System.Drawing.Point(0, 413);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(44, 44);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 16;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SEM_Hospital.Properties.Resources.Doctor1;
            this.pictureBox4.Location = new System.Drawing.Point(3, 237);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(44, 44);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 16;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SEM_Hospital.Properties.Resources.Patient;
            this.pictureBox3.Location = new System.Drawing.Point(3, 146);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(44, 44);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 16;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 552);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(81, 80);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(151, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // LTestIdTb
            // 
            this.LTestIdTb.Location = new System.Drawing.Point(232, 160);
            this.LTestIdTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LTestIdTb.Name = "LTestIdTb";
            this.LTestIdTb.Size = new System.Drawing.Size(189, 27);
            this.LTestIdTb.TabIndex = 199;
            // 
            // LabTestDGV
            // 
            this.LabTestDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LabTestDGV.Location = new System.Drawing.Point(232, 402);
            this.LabTestDGV.Name = "LabTestDGV";
            this.LabTestDGV.RowHeadersWidth = 51;
            this.LabTestDGV.RowTemplate.Height = 29;
            this.LabTestDGV.Size = new System.Drawing.Size(672, 219);
            this.LabTestDGV.TabIndex = 207;
            // 
            // LCostTb
            // 
            this.LCostTb.Location = new System.Drawing.Point(704, 163);
            this.LCostTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LCostTb.Name = "LCostTb";
            this.LCostTb.Size = new System.Drawing.Size(173, 27);
            this.LCostTb.TabIndex = 199;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(704, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 32);
            this.label2.TabIndex = 193;
            this.label2.Text = "Cost";
            // 
            // LUpdateBtn
            // 
            this.LUpdateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LUpdateBtn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LUpdateBtn.ForeColor = System.Drawing.Color.Black;
            this.LUpdateBtn.Location = new System.Drawing.Point(525, 259);
            this.LUpdateBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LUpdateBtn.Name = "LUpdateBtn";
            this.LUpdateBtn.Size = new System.Drawing.Size(97, 53);
            this.LUpdateBtn.TabIndex = 213;
            this.LUpdateBtn.Text = "Update";
            this.LUpdateBtn.UseVisualStyleBackColor = false;
            this.LUpdateBtn.Click += new System.EventHandler(this.LUpdateBtn_Click);
            // 
            // LSearchBtn
            // 
            this.LSearchBtn.BackColor = System.Drawing.Color.LimeGreen;
            this.LSearchBtn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LSearchBtn.ForeColor = System.Drawing.Color.Black;
            this.LSearchBtn.Location = new System.Drawing.Point(669, 259);
            this.LSearchBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LSearchBtn.Name = "LSearchBtn";
            this.LSearchBtn.Size = new System.Drawing.Size(91, 53);
            this.LSearchBtn.TabIndex = 212;
            this.LSearchBtn.Text = "Search";
            this.LSearchBtn.UseVisualStyleBackColor = false;
            this.LSearchBtn.Click += new System.EventHandler(this.LSearchBtn_Click);
            // 
            // LAddBtn
            // 
            this.LAddBtn.BackColor = System.Drawing.Color.LimeGreen;
            this.LAddBtn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LAddBtn.ForeColor = System.Drawing.Color.Black;
            this.LAddBtn.Location = new System.Drawing.Point(235, 259);
            this.LAddBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LAddBtn.Name = "LAddBtn";
            this.LAddBtn.Size = new System.Drawing.Size(99, 53);
            this.LAddBtn.TabIndex = 211;
            this.LAddBtn.Text = "Add";
            this.LAddBtn.UseVisualStyleBackColor = false;
            this.LAddBtn.Click += new System.EventHandler(this.LAddBtn_Click);
            // 
            // LDeleteBtn
            // 
            this.LDeleteBtn.BackColor = System.Drawing.Color.Yellow;
            this.LDeleteBtn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LDeleteBtn.ForeColor = System.Drawing.Color.Black;
            this.LDeleteBtn.Location = new System.Drawing.Point(378, 259);
            this.LDeleteBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LDeleteBtn.Name = "LDeleteBtn";
            this.LDeleteBtn.Size = new System.Drawing.Size(96, 53);
            this.LDeleteBtn.TabIndex = 210;
            this.LDeleteBtn.Text = "Delete";
            this.LDeleteBtn.UseVisualStyleBackColor = false;
            this.LDeleteBtn.Click += new System.EventHandler(this.LDeleteBtn_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(394, 317);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 23);
            this.label10.TabIndex = 209;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(235, 317);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 23);
            this.label9.TabIndex = 208;
            // 
            // LClearTb
            // 
            this.LClearTb.BackColor = System.Drawing.Color.Teal;
            this.LClearTb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LClearTb.Location = new System.Drawing.Point(795, 259);
            this.LClearTb.Name = "LClearTb";
            this.LClearTb.Size = new System.Drawing.Size(94, 52);
            this.LClearTb.TabIndex = 214;
            this.LClearTb.Text = "Clear";
            this.LClearTb.UseVisualStyleBackColor = false;
            this.LClearTb.Click += new System.EventHandler(this.LClearTb_Click);
            // 
            // LNameTb
            // 
            this.LNameTb.Location = new System.Drawing.Point(457, 160);
            this.LNameTb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LNameTb.Name = "LNameTb";
            this.LNameTb.Size = new System.Drawing.Size(216, 27);
            this.LNameTb.TabIndex = 199;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.DarkRed;
            this.label8.Location = new System.Drawing.Point(478, 124);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(133, 32);
            this.label8.TabIndex = 193;
            this.label8.Text = "Test Name";
            // 
            // LabTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(928, 655);
            this.Controls.Add(this.LClearTb);
            this.Controls.Add(this.LUpdateBtn);
            this.Controls.Add(this.LSearchBtn);
            this.Controls.Add(this.LAddBtn);
            this.Controls.Add(this.LDeleteBtn);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.LCostTb);
            this.Controls.Add(this.LNameTb);
            this.Controls.Add(this.LTestIdTb);
            this.Controls.Add(this.LabTestDGV);
            this.Name = "LabTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Staff";
            this.Load += new System.EventHandler(this.LabTest_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LabTestDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox LTestIdTb;
        private System.Windows.Forms.DataGridView LabTestDGV;
        private System.Windows.Forms.TextBox LCostTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button LUpdateBtn;
        private System.Windows.Forms.Button LSearchBtn;
        private System.Windows.Forms.Button LAddBtn;
        private System.Windows.Forms.Button LDeleteBtn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.Button LClearTb;
        private System.Windows.Forms.TextBox LNameTb;
        private System.Windows.Forms.Label label8;
    }
}